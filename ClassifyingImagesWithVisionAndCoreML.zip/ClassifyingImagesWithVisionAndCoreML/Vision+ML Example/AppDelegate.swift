/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains the application's delegate.
*/

import UIKit
import GoogleMaps

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        GMSServices.provideAPIKey("AIzaSyB0wFMcITypbpQrcy0d4tKS-Vx13F52Bfw")
        //GMSServices.provideAPIKey("AIzaSyAVrlbbkx1_b6OV0OTyGgqnzwRake-Ks7E")
        return true
    }

}
