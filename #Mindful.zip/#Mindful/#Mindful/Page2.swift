//
//  Page2.swift
//  #Mindful
//
//  Created by Donut on 3/23/19.
//  Copyright © 2019 Donut. All rights reserved.
//

import UIKit

class Page2: NSObject {

}
